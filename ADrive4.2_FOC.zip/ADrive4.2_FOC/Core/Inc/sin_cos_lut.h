#ifndef SIN_COS_LUT_H
#define SIN_COS_LUT_H

#include "math.h"
#include "stdint.h"

#define LUT_SIZE 1024
#define TWO_PI 6.28318530718f

// LUT 배열 선언 (초기화 전에는 값이 정의되지 않음)
extern float sin_lut[LUT_SIZE];
extern float cos_lut[LUT_SIZE];

// LUT 초기화 함수: 시스템 초기화 시 한 번 호출하여 LUT를 계산
void init_sin_cos_lut(void);

// fast_sin: 주어진 theta (라디안) 값에 대해 LUT를 이용하여 sine 값을 반환
static inline float fast_sin(float theta)
{
    // theta를 [0, 2π) 범위로 정규화
    while (theta < 0)
        theta += TWO_PI;
    while (theta >= TWO_PI)
        theta -= TWO_PI;
    uint32_t index = (uint32_t)((theta / TWO_PI) * LUT_SIZE) % LUT_SIZE;
    return sin_lut[index];
}

// fast_cos: 주어진 theta (라디안) 값에 대해 LUT를 이용하여 cosine 값을 반환
static inline float fast_cos(float theta)
{
    while (theta < 0)
        theta += TWO_PI;
    while (theta >= TWO_PI)
        theta -= TWO_PI;
    uint32_t index = (uint32_t)((theta / TWO_PI) * LUT_SIZE) % LUT_SIZE;
    return cos_lut[index];
}

#endif // SIN_COS_LUT_H
