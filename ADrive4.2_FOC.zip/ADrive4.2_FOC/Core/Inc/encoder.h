#ifndef ENCODER_H
#define ENCODER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"

// 엔코더 상태 구조체 (각도는 도 단위, 속도는 도/초)
typedef struct {
    double angle;           // 단일 회전 각도 (도)
    double velocity;        // 로터 속도 (도/초)
    uint8_t error_bit;      // 오류 비트
    uint8_t warning_bit;    // 경고 비트
    uint8_t crc;            // 수신된 CRC 값
    uint8_t calculated_crc; // 계산된 CRC 값
} Encoder_State_t;

extern volatile Encoder_State_t encoder_state;

// 엔코더 데이터를 파싱하여 단일 회전 각도(도)를 반환 및 상태 업데이트
double EncoderParseSingleTurnToDegrees(uint8_t *data);

// 6바이트 데이터에 대한 CRC6 계산 함수
uint8_t EncoderCalculateCRC6(uint8_t *data, uint8_t length);

// FreeRTOS 태스크: SPI를 통해 엔코더 데이터를 주기적으로 읽어와 상태를 업데이트
void EncoderTimerCallback(void);
void EncoderTask(void *argument);

#ifdef __cplusplus
}
#endif

#endif // ENCODER_H
