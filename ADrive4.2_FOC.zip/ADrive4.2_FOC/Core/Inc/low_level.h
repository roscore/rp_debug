#ifndef LOW_LEVEL_H
#define LOW_LEVEL_H

#ifdef __cplusplus
extern "C" {
#endif

// Vbus 측정 함수 (Volt 단위 반환)
float LowLevel_GetVbus(void);

// Phase A 전류 측정 함수 (Ampere 단위 반환)
float LowLevel_GetPhaseACurrent(void);

// ADC 캘리브레이션 함수
void LowLevel_ADC_Calibrate(void);

#ifdef __cplusplus
}
#endif

#endif // LOW_LEVEL_H
