#ifndef __AXIS_CONTROLLER_H
#define __AXIS_CONTROLLER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"

typedef enum {
    MOTOR_STATE_IDLE,
    MOTOR_STATE_STARTUP,
    MOTOR_STATE_RUNNING,
    MOTOR_STATE_ERROR
} MotorState_t;

typedef enum {
    ERROR_NONE = 0,
    ERROR_OVERVOLTAGE,
    ERROR_OVERCURRENT,
    ERROR_OVERTEMPERATURE,
    ERROR_BAD_INPUT
} SafetyError_t;

typedef struct {
    float stiffness;
    float damping;
} ImpedanceParams_t;

typedef struct {
    MotorState_t state;
    float target_position;
    float target_velocity;
    float target_acceleration;
    SafetyError_t error_code;
    float voltage_threshold;
    float current_threshold;
    float temperature_threshold;
    ImpedanceParams_t impedance;
    float traj_filter_coeff[3];
    float traj_state[2];
    uint32_t safety_timer; // 연속 초과 체크용 (ms)
} AxisController_t;

extern AxisController_t axis_controller;

void AxisController_Init(AxisController_t *axis);
void AxisController_Update(AxisController_t *axis);
void AxisController_GenerateTrajectory(AxisController_t *axis, float target_position);
void AxisController_SafetyCheckAdvanced(AxisController_t *axis);
float AxisController_ImpedanceControl_Update(AxisController_t *axis, float current_position, float current_velocity);

#ifdef __cplusplus
}
#endif

#endif /* __AXIS_CONTROLLER_H */
