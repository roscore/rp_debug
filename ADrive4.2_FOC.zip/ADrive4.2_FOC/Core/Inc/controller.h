#ifndef CONTROLLER_H
#define CONTROLLER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"

/**
 * @brief PI Controller 구조체
 */
typedef struct {
    float Kp;              // 비례 상수
    float Ki;              // 적분 상수
    float integrator;      // 적분기 값
    float integrator_min;  // 적분기 하한 (anti-windup)
    float integrator_max;  // 적분기 상한 (anti-windup)
    float output_min;      // 출력 하한
    float output_max;      // 출력 상한
    float last_error;      // 이전 오차 (integrator reset 용)
} PI_Controller_t;

/**
 * @brief PI 컨트롤러 초기화 함수
 * @param controller: PI 컨트롤러 구조체 포인터
 * @param Kp: 비례 상수
 * @param Ki: 적분 상수
 * @param integrator_min: 적분기 최소값
 * @param integrator_max: 적분기 최대값
 * @param output_min: 출력 최소값
 * @param output_max: 출력 최대값
 */
void PI_Controller_Init(PI_Controller_t *controller, float Kp, float Ki,
                        float integrator_min, float integrator_max,
                        float output_min, float output_max);

/**
 * @brief PI 컨트롤러 업데이트 함수
 * @param controller: PI 컨트롤러 구조체 포인터
 * @param error: 현재 오차 값
 * @param dt: 시간 간격 (초)
 * @retval PI 컨트롤러의 출력
 */
float PI_Controller_Update(PI_Controller_t *controller, float error, float dt);

#ifdef __cplusplus
}
#endif

#endif // CONTROLLER_H
