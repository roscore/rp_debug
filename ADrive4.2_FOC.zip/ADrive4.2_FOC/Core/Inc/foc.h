#ifndef __FOC_H
#define __FOC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stm32f7xx_hal.h"
#include "math.h"
#include "sin_cos_lut.h"  // LUT 기반 삼각함수 함수를 사용하기 위해 포함

/* 모터 파라미터 구조체 */
typedef struct {
    uint16_t pole_count;   // 모터 극수 (예: 14)
    float inductance;      // 인덕턴스 [H]
    float resistance;      // 저항 [Ohm]
} MotorParams_t;

extern MotorParams_t motor_params;

/* FOC 관련 변수들 */
extern volatile float measured_IB;
extern volatile float measured_IC;
extern volatile float measured_Vbus;
extern volatile float measured_PhaseA_Current;
extern volatile uint32_t foc_cycle_time; // FOC 업데이트 루프 실행 시간을 마이크로초 단위로 저장
extern volatile uint8_t safety_mode;

/* 인라인 변환 함수들 (LUT 기반 삼각함수 사용) */
__STATIC_INLINE void ClarkeTransform(float Ia, float Ib, float Ic, float *Ialpha, float *Ibeta)
{
    *Ialpha = Ia;
    *Ibeta = (Ia + 2.0f * Ib) / sqrtf(3.0f);
}

__STATIC_INLINE void ParkTransform(float Ialpha, float Ibeta, float theta, float *Id, float *Iq)
{
    *Id = Ialpha * fast_cos(theta) + Ibeta * fast_sin(theta);
    *Iq = -Ialpha * fast_sin(theta) + Ibeta * fast_cos(theta);
}

__STATIC_INLINE void InvParkTransform(float Vd, float Vq, float theta, float *Valpha, float *Vbeta)
{
    *Valpha = Vd * fast_cos(theta) - Vq * fast_sin(theta);
    *Vbeta = Vd * fast_sin(theta) + Vq * fast_cos(theta);
}

/* 함수 프로토타입 */
void GenerateSVPWM(float Valpha, float Vbeta);
void FOC_Update(void);
float GetRotorAngle(void);

#ifdef __cplusplus
}
#endif

#endif /* __FOC_H */
