#include "controller.h"

void PI_Controller_Init(PI_Controller_t *controller, float Kp, float Ki,
                        float integrator_min, float integrator_max,
                        float output_min, float output_max)
{
    controller->Kp = Kp;
    controller->Ki = Ki;
    controller->integrator = 0.0f;
    controller->integrator_min = integrator_min;
    controller->integrator_max = integrator_max;
    controller->output_min = output_min;
    controller->output_max = output_max;
    controller->last_error = 0.0f;
}

float PI_Controller_Update(PI_Controller_t *controller, float error, float dt)
{
    // 만약 오차의 부호가 바뀌면 integrator를 리셋 (anti-windup)
    if ((error * controller->last_error) < 0.0f)
    {
        controller->integrator = 0.0f;
    }

    // 현재 오차를 적분 (dt: 시간 간격, 초 단위)
    controller->integrator += error * dt;

    // 적분기 값 클램핑 (anti-windup)
    if (controller->integrator > controller->integrator_max)
    {
        controller->integrator = controller->integrator_max;
    }
    else if (controller->integrator < controller->integrator_min)
    {
        controller->integrator = controller->integrator_min;
    }

    // PI 제어 출력 계산
    float output = controller->Kp * error + controller->Ki * controller->integrator;

    // 출력 클램핑
    if (output > controller->output_max)
    {
        output = controller->output_max;
    }
    else if (output < controller->output_min)
    {
        output = controller->output_min;
    }

    controller->last_error = error;

    return output;
}
