#include "low_level.h"
#include "adc.h"
#include "main.h"

// 여기서 adc1_buffer는 main.c에서 전역으로 선언된 DMA 버퍼입니다.
extern uint16_t adc1_buffer[3];

#define VBUS_REF_VOLTAGE         3.3f
#define ADC_MAX_VALUE            4095.0f
#define VBUS_CALIBRATION_FACTOR  18.0f  // 실제 전압 분배 회로에 맞게 조정

// IIR 필터 계수 (0~1, 값이 작을수록 필터링 효과가 큼)
#define ALPHA_VBUS    0.05f
#define ALPHA_PHASEA  0.1f

// 정적 변수: 필터링된 값 및 캘리브레이션 오프셋
static float filtered_vbus = 0.0f;
static float filtered_phaseA = 0.0f;
static float phaseA_offset = 2048.0f;  // 기본 오프셋 (ADC 중앙값)

// ADC 캘리브레이션 함수: 시스템 시작 시 호출하여 오프셋 및 초기 필터링 값을 설정
void LowLevel_ADC_Calibrate(void)
{
    // 간단한 예: ADC 버퍼의 첫 번째 샘플을 이용해 Phase A 오프셋을 결정
    phaseA_offset = (float)adc1_buffer[0];

    // Vbus의 경우, 별도 오프셋이 필요 없다고 가정하고 초기 필터 값을 설정
    filtered_vbus = ((float)adc1_buffer[2] / ADC_MAX_VALUE) * VBUS_REF_VOLTAGE * VBUS_CALIBRATION_FACTOR;

    // Phase A 초기 필터 값은 오프셋 차이를 기반으로 초기화
    filtered_phaseA = ((float)adc1_buffer[0] - phaseA_offset) * 0.005f;
}

float LowLevel_GetVbus(void)
{
    // ADC1의 Rank 3 채널 값을 읽어 원시 Vbus 전압 계산
    float raw_vbus = ((float)adc1_buffer[2] / ADC_MAX_VALUE) * VBUS_REF_VOLTAGE * VBUS_CALIBRATION_FACTOR;
    // IIR 필터 적용: 새 샘플과 이전 필터값의 가중 평균 계산
    filtered_vbus = ALPHA_VBUS * raw_vbus + (1.0f - ALPHA_VBUS) * filtered_vbus;
    return filtered_vbus;
}

float LowLevel_GetPhaseACurrent(void)
{
    // ADC1의 Rank 1 채널 값에서 Phase A 오프셋을 제거하고 보정 상수 적용
    float raw_phaseA = (((float)adc1_buffer[0] - phaseA_offset) * 0.005f);
    // IIR 필터 적용: 새 샘플과 이전 필터값의 가중 평균 계산
    filtered_phaseA = ALPHA_PHASEA * raw_phaseA + (1.0f - ALPHA_PHASEA) * filtered_phaseA;
    return filtered_phaseA;
}
