/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    encoder.c
  * @brief   Encoder driver using SPI (BISS‑C protocol) – TIM6 기반 업데이트
  ******************************************************************************
  * @attention
  *
  * 이 예시는 TIM6 인터럽트에서 SPI DMA 전송을 시작하여
  * 엔코더 데이터를 주기적으로 업데이트하는 방식으로 구현되었습니다.
  * FOC_Update는 TIM13에서 25kHz로 실행되며, 엔코더 업데이트는 독립적으로 동작합니다.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
#include "encoder.h"
#include "spi.h"
#include "stm32f7xx_hal.h"
#include <math.h>

// 전역 엔코더 상태 변수 (각도: 도, 속도: 도/초)
volatile Encoder_State_t encoder_state = {0};

// SPI 전송을 위한 TX/RX 버퍼 및 관련 변수
static uint8_t encoderTxData = 0xFF;
volatile uint8_t encoderRxData[7];
volatile uint8_t encoderDmaInProgress = 0;
uint32_t encoderLastTick = 0;
double encoderLastAngle = 0.0;

// 디버그 및 검증용 변수 (live expressions에서 확인)
volatile uint32_t encoderTimerCount = 0;       // TIM6 인터럽트 호출 횟수
volatile uint32_t encoderDmaCompleteCount = 0;   // DMA 전송 완료 횟수

// 추가: 엔코더 주기 측정을 위한 변수
volatile uint32_t encoderCycleTime = 0;          // 한 사이클 동안의 CPU 사이클 수
volatile uint32_t encoderCycleTimeUs = 0;        // 한 사이클 동안의 시간 (마이크로초)
static uint32_t encoderLastCycleTick = 0;

/**
  * @brief  BISS-C 프로토콜에 따라 단일 회전 각도를 계산하여 반환 및 상태 업데이트
  * @param  data: 수신된 데이터 배열
  * @retval 계산된 각도 (도 단위)
  */
double EncoderParseSingleTurnToDegrees(uint8_t *data)
{
    // BISS-C 프로토콜: data[3] 하위 7비트, data[4] 8비트, data[5] 하위 1비트 사용
    uint32_t singleTurnRaw = (((data[3] & 0x7F) << 9) | (data[4] << 1) | (data[5] & 0x01));
    uint32_t resolution = 1 << 16;  // 16비트 해상도 (65536)
    double angle = (singleTurnRaw * 360.0) / resolution;

    encoder_state.angle = angle;
    encoder_state.error_bit = (data[5] >> 7) & 0x01;
    encoder_state.warning_bit = (data[5] >> 6) & 0x01;
    encoder_state.crc = ((data[5] & 0x3F) << 1) | ((data[6] >> 7) & 0x01);
    encoder_state.calculated_crc = EncoderCalculateCRC6(data, 6);

    return angle;
}

/**
  * @brief  6바이트 데이터에 대한 CRC6 계산 (BISS-C 프로토콜용)
  * @param  data: 데이터 배열, length: 사용 바이트 수
  * @retval 계산된 CRC6 값
  */
uint8_t EncoderCalculateCRC6(uint8_t *data, uint8_t length)
{
    uint8_t crc = 0;
    for (uint8_t i = 0; i < length; i++)
    {
        uint8_t byte = data[i];
        for (uint8_t bit = 0; bit < 8; bit++)
        {
            uint8_t bitValue = (byte >> (7 - bit)) & 0x01;
            crc = ((crc << 1) | bitValue) & 0x3F;
            if (crc & 0x20)  // 다항식: x^6 + x^1 + 1 (0x43)
            {
                crc ^= 0x43;
            }
        }
    }
    return crc;
}

/**
  * @brief  TIM6 인터럽트에 의해 주기적으로 호출되어 SPI DMA 전송을 시작하는 함수
  *         동시에, 이 함수는 엔코더 업데이트 주기를 측정하여 microsecond 단위로 저장합니다.
  */
void EncoderTimerCallback(void)
{
    // 엔코더 주기 측정: 현재 DWT 사이클 카운트 가져오기
    uint32_t currentCycle = DWT->CYCCNT;
    if (encoderLastCycleTick != 0)
    {
        encoderCycleTime = currentCycle - encoderLastCycleTick;
        // CPU 클럭 216MHz 기준: 1us = 216 사이클
        encoderCycleTimeUs = encoderCycleTime / 216;
    }
    encoderLastCycleTick = currentCycle;

    // 디버그: TIM6 인터럽트 호출 카운트 증가
    encoderTimerCount++;

    // 이전 전송이 진행 중이면 새 전송을 시작하지 않음
    if (encoderDmaInProgress)
    {
        return;
    }

    encoderDmaInProgress = 1;
    // SPI2를 통해 DMA 전송 시작 (tx: encoderTxData, rx: encoderRxData, 길이: 7)
    if (HAL_SPI_TransmitReceive_DMA(&hspi2, &encoderTxData, (uint8_t*)encoderRxData, 7) != HAL_OK)
    {
        // 전송 시작 실패 시 플래그를 클리어
        encoderDmaInProgress = 0;
    }
}

/**
  * @brief  SPI 전송/수신 DMA 완료 콜백
  * @param  hspi: SPI 핸들
  */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi2)
    {
        uint32_t currentTick = HAL_GetTick();
        double currentAngle = EncoderParseSingleTurnToDegrees((uint8_t*)encoderRxData);
        double dt = (currentTick - encoderLastTick) / 1000.0;  // dt (초)
        double dAngle = currentAngle - encoderLastAngle;
        // 각도 wrap-around 보정
        if (dAngle > 180.0)
            dAngle -= 360.0;
        else if (dAngle < -180.0)
            dAngle += 360.0;
        if (dt > 0)
        {
            encoder_state.velocity = dAngle / dt;
        }
        encoderLastTick = currentTick;
        encoderLastAngle = currentAngle;

        // 디버그: DMA 완료 횟수 증가
        encoderDmaCompleteCount++;

        // SPI 전송 완료 후 플래그 클리어
        encoderDmaInProgress = 0;
    }
}

/**
  * @brief  FreeRTOS 태스크: SPI를 통해 엔코더 데이터를 주기적으로 읽어와 상태를 업데이트
  *         (TIM6 인터럽트를 사용하므로 이 태스크는 사용하지 않아도 됩니다.)
  */
void EncoderTask(void *argument)
{
    // TIM6 인터럽트를 사용하여 엔코더 업데이트를 수행하므로,
    // 이 태스크는 단순히 무한 대기하거나 디버그 목적으로 사용할 수 있습니다.
    for (;;)
    {
        osDelay(1000);
    }
}
