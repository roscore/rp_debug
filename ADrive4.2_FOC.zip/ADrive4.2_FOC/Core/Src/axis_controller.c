#include "axis_controller.h"
#include "foc.h"
#include "main.h"
#include "stm32f7xx_hal.h"
#include "cmsis_os.h"
#include "encoder.h"
#include "math.h"

/* axis_controller 전역 변수는 이 파일에서 한 번만 정의 */
AxisController_t axis_controller;

void AxisController_Init(AxisController_t *axis)
{
    axis->state = MOTOR_STATE_IDLE;
    axis->target_position = 0.0f;
    axis->target_velocity = 0.0f;
    axis->target_acceleration = 0.0f;
    axis->error_code = ERROR_NONE;
    axis->voltage_threshold = 65.0f;
    axis->current_threshold = 80.0f;
    axis->temperature_threshold = 80.0f;
    axis->impedance.stiffness = 10.0f;
    axis->impedance.damping = 0.5f;
    axis->traj_filter_coeff[0] = 0.5f;
    axis->traj_filter_coeff[1] = 0.3f;
    axis->traj_filter_coeff[2] = 0.2f;
    axis->traj_state[0] = 0.0f;
    axis->traj_state[1] = 0.0f;
    axis->safety_timer = 0;
}

void AxisController_GenerateTrajectory(AxisController_t *axis, float target_position)
{
	target_position = 90.0f;
    axis->target_position = target_position;
    float current_pos = GetRotorAngle(); // GetRotorAngle()은 foc 모듈에서 외부 엔코더 값 반환
    float pos_error = target_position - current_pos;
    float y = axis->traj_filter_coeff[0] * pos_error +
              axis->traj_filter_coeff[1] * axis->traj_state[0] +
              axis->traj_filter_coeff[2] * axis->traj_state[1];
    axis->traj_state[1] = axis->traj_state[0];
    axis->traj_state[0] = y;
    axis->target_velocity = y * 2.0f;
    axis->target_acceleration = 0.0f;
}

void AxisController_SafetyCheckAdvanced(AxisController_t *axis)
{
    if (measured_Vbus > axis->voltage_threshold) {
        if (axis->safety_timer == 0)
            axis->safety_timer = HAL_GetTick();
        else if (HAL_GetTick() - axis->safety_timer > 50) {
            axis->state = MOTOR_STATE_ERROR;
            axis->error_code = ERROR_OVERVOLTAGE;
            safety_mode = 1;
        }
    } else {
        axis->safety_timer = 0;
    }
    if (fabsf(measured_IB) > axis->current_threshold) {
        axis->state = MOTOR_STATE_ERROR;
        axis->error_code = ERROR_OVERCURRENT;
        safety_mode = 1;
    }
    extern float measured_temperature;
    if (measured_temperature > axis->temperature_threshold) {
        axis->state = MOTOR_STATE_ERROR;
        axis->error_code = ERROR_OVERTEMPERATURE;
        safety_mode = 1;
    }
    if (GetRotorAngle() < -360.0f || GetRotorAngle() > 360.0f) {
        axis->state = MOTOR_STATE_ERROR;
        axis->error_code = ERROR_BAD_INPUT;
        safety_mode = 1;
    }
}

float AxisController_ImpedanceControl_Update(AxisController_t *axis, float current_position, float current_velocity)
{
    float position_error = axis->target_position - current_position;
    float force = axis->impedance.stiffness * position_error - axis->impedance.damping * current_velocity;
    return force;
}

void AxisController_Update(AxisController_t *axis)
{
    if (axis->state == MOTOR_STATE_IDLE && HAL_GetTick() > 5000)
        axis->state = MOTOR_STATE_STARTUP;

    /* 테스트: 목표 위치를 90°로 지정 */
    AxisController_GenerateTrajectory(axis, 90.0f);
    AxisController_SafetyCheckAdvanced(axis);

    if (axis->state == MOTOR_STATE_STARTUP) {
        if (HAL_GetTick() > 6000 && measured_Vbus < axis->voltage_threshold)
            axis->state = MOTOR_STATE_RUNNING;
    }

    if (axis->state == MOTOR_STATE_RUNNING) {
        float current_pos = GetRotorAngle();
        float current_velocity = encoder_state.velocity;
        float impedance_output = AxisController_ImpedanceControl_Update(axis, current_pos, current_velocity);
        (void)impedance_output; // impedance_output는 필요 시 추가 처리
    }
}
