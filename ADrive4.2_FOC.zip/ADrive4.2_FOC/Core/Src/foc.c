/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    foc.c
  * @brief   Cubemars RI85 기반 센서리스 FOC (Field Oriented Control)
  *          안전 테스트를 위해 5초 후 외부 엔코더를 이용하여 목표 위치 0° 제어
  ******************************************************************************
  * @attention
  *
  * 이 코드는 ODrive 3.6 펌웨어의 최적화 기법을 참고하여 작성되었으며,
  * 특히 LUT 기반 삼각함수 최적화를 통해 연산 부하를 크게 줄였습니다.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
#include "foc.h"
#include "tim.h"
#include "low_level.h"
#include "encoder.h"
#include "controller.h"
#include "axis_controller.h"
#include <math.h>

/* 외부 변수: main.c에서 DMA로 ADC1 데이터를 읽어오는 버퍼 */
extern uint16_t adc1_buffer[3];

volatile float measured_IB = 0.0f;
volatile float measured_IC = 0.0f;
volatile float measured_Vbus = 0.0f;
volatile float measured_PhaseA_Current = 0.0f;
volatile uint32_t foc_cycle_time = 0;
volatile uint8_t safety_mode = 0;

#define TEST_IQ_MODE 1

#ifdef TEST_IQ_MODE
	float test_iq_command = 1.0f; // 테스트용 목표 current (예: 50 A, 실제 하드웨어에 맞게 조정)
#endif


MotorParams_t motor_params = {
  .pole_count = 14,
  .inductance = 0.0005f,
  .resistance = 0.05f
};

#define TIM1_PERIOD   3500
#define TIM1_CENTER   (TIM1_PERIOD / 2)
#define SVPWM_SCALE   35.0f
#define MAX_PWM_STEP  20
#define MAX_PWM_LIMIT 150

float GetRotorAngle(void)
{
    return encoder_state.angle;
}

void GenerateSVPWM(float Valpha, float Vbeta)
{
    float V_A = Valpha;
    float V_B = (-0.5f * Valpha) + ((sqrtf(3.0f) / 2.0f) * Vbeta);
    float V_C = (-0.5f * Valpha) - ((sqrtf(3.0f) / 2.0f) * Vbeta);

    int32_t new_pwmA = (int32_t)(TIM1_CENTER + V_A * SVPWM_SCALE);
    int32_t new_pwmB = (int32_t)(TIM1_CENTER + V_B * SVPWM_SCALE);
    int32_t new_pwmC = (int32_t)(TIM1_CENTER + V_C * SVPWM_SCALE);

    if (new_pwmA < 0) new_pwmA = 0;
    if (new_pwmA > TIM1_PERIOD) new_pwmA = TIM1_PERIOD;
    if (new_pwmB < 0) new_pwmB = 0;
    if (new_pwmB > TIM1_PERIOD) new_pwmB = TIM1_PERIOD;
    if (new_pwmC < 0) new_pwmC = 0;
    if (new_pwmC > TIM1_PERIOD) new_pwmC = TIM1_PERIOD;

    static int32_t prev_pwmA = TIM1_CENTER, prev_pwmB = TIM1_CENTER, prev_pwmC = TIM1_CENTER;
    int32_t deltaA = new_pwmA - prev_pwmA;
    if (deltaA > MAX_PWM_STEP) deltaA = MAX_PWM_STEP;
    else if (deltaA < -MAX_PWM_STEP) deltaA = -MAX_PWM_STEP;
    int32_t pwmA = prev_pwmA + deltaA;

    int32_t deltaB = new_pwmB - prev_pwmB;
    if (deltaB > MAX_PWM_STEP) deltaB = MAX_PWM_STEP;
    else if (deltaB < -MAX_PWM_STEP) deltaB = -MAX_PWM_STEP;
    int32_t pwmB = prev_pwmB + deltaB;

    int32_t deltaC = new_pwmC - prev_pwmC;
    if (deltaC > MAX_PWM_STEP) deltaC = MAX_PWM_STEP;
    else if (deltaC < -MAX_PWM_STEP) deltaC = -MAX_PWM_STEP;
    int32_t pwmC = prev_pwmC + deltaC;

    prev_pwmA = pwmA;
    prev_pwmB = pwmB;
    prev_pwmC = pwmC;

    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwmA);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pwmB);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, pwmC);
}

void FOC_Update(void)
{
    uint32_t start = DWT->CYCCNT;

    if (HAL_GetTick() < 5000)
    {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
        return;
    }

    measured_IB = (((float)adc1_buffer[0] - 2048.0f) * 0.005f);
    measured_IC = (((float)adc1_buffer[1] - 2048.0f) * 0.005f);
    measured_Vbus = LowLevel_GetVbus();
    measured_PhaseA_Current = LowLevel_GetPhaseACurrent();

    float Ia = measured_IB;
    float Ib = measured_IC;
    float Ic = -(Ia + Ib);
    float Ialpha, Ibeta;
    ClarkeTransform(Ia, Ib, Ic, &Ialpha, &Ibeta);

    float theta = GetRotorAngle();

    float Id, Iq;
    ParkTransform(Ialpha, Ibeta, theta, &Id, &Iq);

    /* TIM13 설정을 기반으로 dt 산출
       예: htim13.Init.Prescaler = 107, htim13.Init.Period = 99 → foc_timer_clock = 216e6/108 = 2e6 Hz, foc_dt = (99+1)/2e6 = 50e-6초 */
    float foc_timer_clock = 216000000.0f / (htim13.Init.Prescaler + 1);
    float foc_dt = ((float)(htim13.Init.Period + 1)) / foc_timer_clock;

    static PI_Controller_t pi_pos;
    static uint8_t pi_pos_initialized = 0;
    if (!pi_pos_initialized)
    {
//        PI_Controller_Init(&pi_pos, 3.0f, 0.1f, -5.0f, 5.0f, -5.0f, 5.0f);
    	PI_Controller_Init(&pi_pos, 3.0f, 0.2f, -10.0f, 10.0f, -10.0f, 10.0f);

        pi_pos_initialized = 1;
    }
    float pos_error = axis_controller.target_position - encoder_state.angle;
    float desired_Iq = PI_Controller_Update(&pi_pos, pos_error, foc_dt);

	#ifdef TEST_IQ_MODE
		desired_Iq = test_iq_command;
	#endif

    static PI_Controller_t pi_d, pi_q;
    static uint8_t pi_dq_initialized = 0;
    if (!pi_dq_initialized)
    {
        PI_Controller_Init(&pi_d, 0.15f, 0.015f, -100.0f, 100.0f, -100.0f, 100.0f);
        PI_Controller_Init(&pi_q, 0.15f, 0.015f, -100.0f, 100.0f, -100.0f, 100.0f);
        pi_dq_initialized = 1;
    }
    volatile float Vd = PI_Controller_Update(&pi_d, 0.0f - Id, foc_dt);
    volatile float Vq = PI_Controller_Update(&pi_q, desired_Iq - Iq, foc_dt);

    float Valpha, Vbeta;
    InvParkTransform(Vd, Vq, theta, &Valpha, &Vbeta);

    if (safety_mode)
    {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
    }
    else
    {
        GenerateSVPWM(Valpha, Vbeta);
    }

    uint32_t end = DWT->CYCCNT;
    foc_cycle_time = (end - start) / 216;
}
