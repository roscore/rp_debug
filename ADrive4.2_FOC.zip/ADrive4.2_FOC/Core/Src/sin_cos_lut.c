#include "sin_cos_lut.h"

float sin_lut[LUT_SIZE];
float cos_lut[LUT_SIZE];

// init_sin_cos_lut: LUT_SIZE 개의 포인트를 사용해 0 ~ 2π 범위의 sine, cosine 값을 계산
void init_sin_cos_lut(void)
{
    for (uint32_t i = 0; i < LUT_SIZE; i++)
    {
        float angle = ((float)i / (float)LUT_SIZE) * TWO_PI;
        sin_lut[i] = sinf(angle);
        cos_lut[i] = cosf(angle);
    }
}
