#ifndef DRV8353_H
#define DRV8353_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdint.h>

// DRV8353 레지스터 주소 (예시 – 실제 값은 데이터시트를 참고)
typedef enum {
    DRV8353_REG_CTRL1   = 0x00,
    DRV8353_REG_CTRL2   = 0x01,
    DRV8353_REG_STATUS  = 0x02,
    // 추가 레지스터 정의 가능
} DRV8353_Register;

// DRV8353 핸들 구조체: SPI 핸들, 칩 선택 및 Enable 핀 정보 포함
typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef *CS_Port;
    uint16_t CS_Pin;
    // 필요시, 추가 GPIO (Enable 등)
} DRV8353_HandleTypeDef;

// 함수 프로토타입
HAL_StatusTypeDef DRV8353_Init(DRV8353_HandleTypeDef *drv);
HAL_StatusTypeDef DRV8353_WriteRegister(DRV8353_HandleTypeDef *drv, DRV8353_Register reg, uint16_t data);
HAL_StatusTypeDef DRV8353_ReadRegister(DRV8353_HandleTypeDef *drv, DRV8353_Register reg, uint16_t *data);
uint8_t DRV8353_GetFault(DRV8353_HandleTypeDef *drv);
void DRV8353_SetEnable(DRV8353_HandleTypeDef *drv, uint8_t enable);

#ifdef __cplusplus
}
#endif

#endif // DRV8353_H
