#include "drv8353.h"
#include "spi.h"

// 내부 헬퍼 함수: 칩 선택 제어
static void DRV8353_CS_Low(DRV8353_HandleTypeDef *drv) {
    HAL_GPIO_WritePin(drv->CS_Port, drv->CS_Pin, GPIO_PIN_RESET);
}

static void DRV8353_CS_High(DRV8353_HandleTypeDef *drv) {
    HAL_GPIO_WritePin(drv->CS_Port, drv->CS_Pin, GPIO_PIN_SET);
}

// DRV8353 초기화 함수
HAL_StatusTypeDef DRV8353_Init(DRV8353_HandleTypeDef *drv) {
    HAL_StatusTypeDef status;

    // 예시: CTRL1, CTRL2 초기화 (실제 값은 DRV8353 데이터시트를 참고)
    status = DRV8353_WriteRegister(drv, DRV8353_REG_CTRL1, 0x1234);
    if(status != HAL_OK) return status;

    status = DRV8353_WriteRegister(drv, DRV8353_REG_CTRL2, 0x5678);
    if(status != HAL_OK) return status;

    // 추가 보호 기능 레지스터 설정 가능
    return HAL_OK;
}

// DRV8353 레지스터 쓰기 함수
HAL_StatusTypeDef DRV8353_WriteRegister(DRV8353_HandleTypeDef *drv, DRV8353_Register reg, uint16_t data) {
    // 예시: 16비트 전송 - 상위 5비트: 주소, 하위 11비트: 데이터 (실제 bit 배치는 데이터시트 참조)
    uint16_t txData = (((uint16_t)reg & 0x1F) << 11) | (data & 0x07FF);
    uint8_t txBytes[2];
    txBytes[0] = (txData >> 8) & 0xFF;
    txBytes[1] = txData & 0xFF;

    DRV8353_CS_Low(drv);
    HAL_StatusTypeDef status = HAL_SPI_Transmit(drv->hspi, txBytes, 2, 10);
    DRV8353_CS_High(drv);

    return status;
}

// DRV8353 레지스터 읽기 함수
HAL_StatusTypeDef DRV8353_ReadRegister(DRV8353_HandleTypeDef *drv, DRV8353_Register reg, uint16_t *data) {
    uint16_t txData = (((uint16_t)reg & 0x1F) << 11) | (1 << 10); // 읽기 비트 설정 (예시)
    uint8_t txBytes[2];
    uint8_t rxBytes[2] = {0};

    txBytes[0] = (txData >> 8) & 0xFF;
    txBytes[1] = txData & 0xFF;

    DRV8353_CS_Low(drv);
    HAL_StatusTypeDef status = HAL_SPI_TransmitReceive(drv->hspi, txBytes, rxBytes, 2, 10);
    DRV8353_CS_High(drv);

    if(status == HAL_OK) {
        *data = ((uint16_t)rxBytes[0] << 8) | rxBytes[1];
    }
    return status;
}

// DRV8353 fault 상태 읽기 함수
uint8_t DRV8353_GetFault(DRV8353_HandleTypeDef *drv) {
    uint16_t regData;
    if(DRV8353_ReadRegister(drv, DRV8353_REG_STATUS, &regData) == HAL_OK) {
        // 예시: STATUS 레지스터의 bit0가 fault 상태라 가정
        return (regData & 0x0001);
    }
    return 0;
}

// DRV8353 Enable 제어 함수 (예시: GPIOA PIN1 사용)
void DRV8353_SetEnable(DRV8353_HandleTypeDef *drv, uint8_t enable) {
    if(enable) {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
    }
}
